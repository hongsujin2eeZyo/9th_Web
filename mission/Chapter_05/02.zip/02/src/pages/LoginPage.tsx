import Login from "../components/Login"

const LoginPage = () => {   
  return (
    <div className="bg-black h-screen pt-50">
        <Login />
    </div>
  )
}

export default LoginPage