const Home = () => {
  return <div className="bg-black h-screen text-white">Home Page</div>;
}


export default Home;